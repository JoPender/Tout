<?php include "template/register.phtml"; ?>
