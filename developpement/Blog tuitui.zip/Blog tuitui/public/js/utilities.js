//function insertBillet(response){
//  $('#section_billet').append(response);
//}

function insertHeader(response){
  $('body').prepend(response);
}
