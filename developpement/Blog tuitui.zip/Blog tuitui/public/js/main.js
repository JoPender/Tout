$(document).ready(function () {

  //for(let i=0 ; i < 3; i++){
  //  $.get('template/home.phtml').done(insertBillet);
//  }

  $.get('template/header.phtml').done(insertHeader);

})
