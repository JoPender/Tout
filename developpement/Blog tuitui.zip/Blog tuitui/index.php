<?php include "template/index.phtml"; ?>
