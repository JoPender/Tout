
<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?= var_dump($_POST); ?>
    <?= var_dump($_FILES['image']); ?>
    <?= date('Y-m-d H:i:s'); ?>
  </body>
</html>
